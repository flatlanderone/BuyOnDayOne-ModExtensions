## Buy On Day One - Telrics Horses V2
Buy On Day One - Telrics Horses V2 lets you buy all the horses from Telrics Horses V2 mod from each trader starting on your first day in the zombie apocalypse. 

## Important Notes 
1. If you install any of the Buy On Day One mods in an existing world, you must reset the trader's inventory using console commands or wait for the trader to reset according to his normal schedule.
2. Not tested in multiplayer.
3. The mods should not affect other vehicle mods (to be confirmed).
4. Removing the mods is safe, but you should reset the trader's inventory using console commands or wait for the trader to reset according to his normal schedule.

## Requirements
 [Telrics Horses V2](https://www.nexusmods.com/7daystodie/mods/7422).
